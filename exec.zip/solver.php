<?php
 if(isset($_POST['submit'])) {
$name = $_POST['name'];
$link = $_POST['link'];
$file = 'solvers.txt';
$fp = fopen($file, 'a');
fwrite($fp, "+------------------------------------------------------------------------+"."\n");
fwrite($fp, "Name:".$name."\n");
fwrite($fp, " Link:".$link."\n\n");
fclose($fp);
 }
 header('Location:solver_list.php');
?>