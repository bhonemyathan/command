<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Test</title>
  </head>
  <body bgcolor="black">
    <style>
          @import url('https://fonts.googleapis.com/css2?family=Viaoda+Libre&display=swap');
      body {
        margin: 0;
        padding: 0;
      }
      pre {
        color: red;
        
      }
      .h2 {
        font-family: 'Viaoda Libre', cursive;
        text-align: center;
        color: #fff;
        text-shadow:
        0 0 7px #fff,
        0 0 10px #fff,
        0 0 21px #fff,
        0 0 42px #f09,
        0 0 82px #f09,
        0 0 92px #f09,
        0 0 102px #f09,
        0 0 151px #f09;
      }
    .link {
      text-decoration: none;
      margin-left: 20px;
      text-align: center;
    }
    .link:hover {
      text-decoration-color: red;
    }
    .p {
      color: red;
      text-align: center;
      font-family: 'Viaoda Libre', cursive;
    }
    .marquee {
        font-family: 'Viaoda Libre', cursive;
        color: #fff;
    }
    </style>
   
    <pre>
               ...
             ;::::;
           ;::::; :;
         ;:::::'   :;
        ;:::::;     ;.
       ,:::::'       ;           OOO\
       ::::::;       ;          OOOOO\
       ;:::::;       ;         OOOOOOOO
      ,;::::::;     ;'         / OOOOOOO
    ;:::::::::`. ,,,;.        /  / DOOOOOO
  .';:::::::::::::::::;,     /  /     DOOOO
 ,::::::;::::::;;;;::::;,   /  /        DOOO
;`::::::`'::::::;;;::::: ,#/  /          DOOO
:`:::::::`;::::::;;::: ;::#  /            DOOO
::`:::::::`;:::::::: ;::::# /              DOO
`:`:::::::`;:::::: ;::::::#/               DOO
 :::`:::::::`;; ;:::::::::##                OO
 ::::`:::::::`;::::::::;:::#                OO
 `:::::`::::::::::::;'`:;::#                O
  `:::::`::::::::;' /  / `:#
   ::::::`:::::;'  /  /   `#
    capture the flag

    </pre>
    <h2 class="h2">Command injection Test</h2>
    <hr>
    <center>
      <br>
      <a href="command1.php" class="link">method1</a>
      <a href="command2.php?id=2" class="link">method2</a>
      <a href="command3.php" class="link">method3</a>
      <a href="solver_add.php" class="link">submit flag</a>
      <br><br>
      <hr></center>
      <marquee class="marquee">Read flag.txt files</marquee>
      <p class="p">Bhone Myat Han</p>

    