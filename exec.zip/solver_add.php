<!DOCTYPE html>
<html>
  <head>
    <title>Solver list add</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  </head>
  <body bgcolor="black">
    <?php
$password = "command1_flag_finish|flag_finish_command2|finish_flag_command3"; 

if (isset($_POST["password"]) && ($_POST["password"]=="$password")) { ?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Viaoda+Libre&display=swap');
      body {
        margin: 0;
        padding: 0;
      }
      pre {
        color: yellow;
      }
      .h2 {
        font-family: 'Viaoda Libre', cursive;
        text-align: center;
        color: #fff;
        text-shadow:
        0 0 7px #fff,
        0 0 10px #fff,
        0 0 21px #fff,
        0 0 42px #f09,
        0 0 82px #f09,
        0 0 92px #f09,
        0 0 102px #f09,
        0 0 151px #f09;
        
      }
input[type=text] {
  padding: 7px ;
  margin: 5px 0;
  border: 1px solid #000000;
  display: block;
  }
input[type=submit] {
  width: 100px;
  padding: 9px;
  margin: 5px 0;
  
  border: 2px solid #000000;
  outline: none;
   background-color:green;
   color:white;
    
}
</style><center>
<form action="solver.php" method="post">
  <h2 class="h2">Add Solver</h2>
  <input type="text" name="name" placeholder="Eg:Lee val"/>
  <input type="text" name="link" placeholder="FB/GitHub acc link"/>
  <input type="submit" name="submit" value="submit"/></center>

  </form>
<?php }
else{ 
  if($_SERVER['REQUEST_METHOD'] == 'POST') {
    ?>
    <script>alert('Sorry Your flag is wrong');</script>
  <?php } ?>
  <style>
@import url('https://fonts.googleapis.com/css2?family=Viaoda+Libre&display=swap');
      body {
        margin: 0;
        padding: 0;
      }
      pre {
        color: yellow;
      }
      .h2 {
        font-family: 'Viaoda Libre', cursive;
        text-align: center;
        color: #fff;
        text-shadow:
        0 0 7px #fff,
        0 0 10px #fff,
        0 0 21px #fff,
        0 0 42px #f09,
        0 0 82px #f09,
        0 0 92px #f09,
        0 0 102px #f09,
        0 0 151px #f09;
        
      }
      input[type=password] {
  padding: 7px ;
  margin: 5px 0;
  border: 1px solid #000000;
  }
input[type=submit] {
  width: 100px;
  padding: 9px;
  margin: 5px 0;
  
  border: 2px solid #000000;
  outline: none;
   background-color:green;
   color:white;
    
}
      </style>
  <h2 class="h2">Enter Flag and add solver list</h2>
 <p align="center"><font color="red">
 <form id ="myForm" method="post"><p align="center">
 <input name="password" type="password" size="25" placeholder="**********" ><input value="Submit" type="submit"></p>
 
 </form>
 <?php } ?>
 </body>
 </html>